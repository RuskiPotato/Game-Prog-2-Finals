using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif


public class BattleHud : MonoBehaviour, IBattleView {
    [Header("Fate")]
    public GameObject fatePanel;
    public DiamondMeter fateMeter;
    public TMP_Text fateValueText;
    public TMP_Text tierText;
    public TMP_Text maliceText;
    public TMP_Text goldText;
    [Header("Suspicion")]
    public GameObject suspicionPanel;
    public Slider suspicionBar;
    public TMP_Text suspicionTierText;
    public TMP_Text suspicionDetailText;

    [Header("Morale")]
    public GameObject moralePanel;
    public Slider moraleBar;
    public TMP_Text moraleTierText;
    public TMP_Text moraleDetailText;

    [Header("Under-unit HP")]
    public UnitHpTag heroHpTag, enemyHpTag;

    [Header("HeroPanel")]
    public GameObject heroProfilePanel;
    public TMP_Text heroText;
    public Slider heroHpBar;
    public AudacityPips audacityPips;
    public TMP_Text audacityText;
    public bool heroProfileAlwaysVisible = false;

    public TMP_Text enemyText;
    public Slider enemyHpBar;

    [Header("Game Master taunt")]
    public GameObject gmPanel;
    public TMP_Text gmText;
    public float gmAutoHideSeconds = 0f;

    [Header("Field")]
    public TMP_Text logText;
    public TMP_Text oddsText;
    public DiceTray diceTray;
    public DiceTray enemyDiceTray;
    [Header("Clash presentation")]
    public RectTransform heroCombatant;
    public RectTransform enemyCombatant;
    public float clashMovePixels = 58f;
    public float clashMoveDuration = 0.28f;
    public float clashResultDuration = 0.95f;
    public float clashWinnerPushPixels = 82f;     // winner lunges this far from home
    public float clashLoserPushPixels = 80f;      // loser is pushed back this far from home
    public TMP_Text turnOrderText;
    public string activeColorHex = "FFD35A";
    public string turnOrderSeparator = "  vs  ";
    public bool showEnemyLandChance = false;

    [Header("Clash cards")]
    public GameObject heroActionPanel;
    public TMP_Text heroActionText;
    public GameObject enemyActionPanel;
    public TMP_Text enemyActionText;

    [Header("Passives")]
    public UnitSelectable heroSelectable, enemySelectable;
    public PassivesPanel heroPassives, enemyPassives;

    [Header("Hand")]
    public HandView hand;

    [Header("Cheat Panel")]
    public CheatPanelView cheatPanel;
    readonly List<ICard> lastCombatCards = new List<ICard>();

    [Header("Pop-ups")]
    public GameObject reactionPanel;
    public Button acceptBtn, rerollBtn, continueBtn;

    public event Action AcceptClicked, RerollClicked, ContinueClicked;
    public event Action<ICard> CardClicked;

    enum Selected { None, Hero, Enemy }
    Selected selected = Selected.None;
    BattleContext lastCtx;
    Coroutine gmHide;
    List<Unit> turnOrder = new List<Unit>();
    Vector2 heroHome, enemyHome;
    bool clashPositionsCached;
    Canvas rootCanvas;

    static void SetText(TMP_Text t, string s) { if (t != null) t.text = s; }
    static void SetActive(GameObject g, bool on) { if (g != null && g.activeSelf != on) g.SetActive(on); }

    void Awake() {
        if (acceptBtn != null) acceptBtn.onClick.AddListener(() => AcceptClicked?.Invoke());
        if (rerollBtn != null) rerollBtn.onClick.AddListener(() => RerollClicked?.Invoke());
        if (continueBtn != null) continueBtn.onClick.AddListener(() => ContinueClicked?.Invoke());
        if (hand != null) hand.CardClicked += card => CardClicked?.Invoke(card);
        if (cheatPanel != null) cheatPanel.CardClicked += card => CardClicked?.Invoke(card);
        SetActive(reactionPanel, false);
        if (continueBtn != null) continueBtn.gameObject.SetActive(false);

        if (heroSelectable != null) heroSelectable.Clicked += _ => Select(Selected.Hero);
        if (enemySelectable != null) enemySelectable.Clicked += _ => Select(Selected.Enemy);
        SetActive(gmPanel, false);
        if (heroPassives != null) heroPassives.Hide();
        if (enemyPassives != null) enemyPassives.Hide();
        SetActive(heroProfilePanel, heroProfileAlwaysVisible);
        if (heroCombatant == null) {
            var go = GameObject.Find("HeroImage");
            if (go != null) heroCombatant = go.GetComponent<RectTransform>();
        }
        if (enemyCombatant == null) {
            var go = GameObject.Find("EnemyImage");
            if (go != null) enemyCombatant = go.GetComponent<RectTransform>();
        }
        rootCanvas = GetComponentInParent<Canvas>();
        if (rootCanvas == null) rootCanvas = FindFirstObjectByType<Canvas>();
        CacheClashPositions();
    }

    // Works whichever input system the project uses (Player Settings > Active Input Handling).
    static bool EscapePressed() {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        return Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.Escape);
#endif
    }

    void Update() {
        if (EscapePressed()) {
            if (cheatPanel != null && cheatPanel.IsOpen) cheatPanel.Close();
            else if (selected != Selected.None) Select(Selected.None);
        }
    }

    public void Initialize(IEnumerable<ICard> coreCards, IEnumerable<ICard> cheats = null) {
        if (hand != null) hand.Build(coreCards);
        if (cheatPanel != null) {
            cheatPanel.gameObject.SetActive(false);   // keep whatever opens it outside this object
            cheatPanel.Build(cheats);
        }
    }

    public void RefreshCombatHand(CardDeck deck, IEnumerable<CardData> coreCards) {
        if (deck == null) return;
        var cards = deck.BuildVisibleCards(coreCards);
        bool changed = cards.Count != lastCombatCards.Count;
        if (!changed) for (int i = 0; i < cards.Count; i++) if (!ReferenceEquals(cards[i], lastCombatCards[i])) { changed = true; break; }
        if (changed) {
            lastCombatCards.Clear(); lastCombatCards.AddRange(cards);
            if (hand != null) hand.Build(cards);
        }
        if (lastCtx != null && hand != null) hand.Refresh(lastCtx);
    }

    // Called by BattleController once initiative is rolled.
    public void SetTurnOrder(List<Unit> order) {
        turnOrder = order ?? new List<Unit>();
        if (lastCtx != null) RefreshTurnOrder(lastCtx);
    }

    // Clicking the selected unit again, or pressing Esc, clears the selection.
    void Select(Selected which) {
        selected = selected == which ? Selected.None : which;
        if (lastCtx != null) RefreshSelection(lastCtx);
    }

    public void Refresh(BattleContext ctx) {
        lastCtx = ctx;
        var fate = ctx.Fate;
        bool revealed = ctx.Progress.FateBarRevealed;

        // Fate: diamond
        SetActive(fatePanel, revealed);
        if (fateMeter != null) fateMeter.SetValue(fate.Fate / 100f);
        SetText(fateValueText, fate.Fate.ToString());
        SetText(tierText, fate.TierName);
        SetText(maliceText, $"Malice dice: {fate.MaliceDice}  (rolling {ctx.CurrentDice})");
        SetText(goldText, $"Gold: {fate.Gold}");

        // Suspicion: right-edge bar
        SetActive(suspicionPanel, revealed);
        if (suspicionBar != null) suspicionBar.value = fate.Suspicion / 100f;
        var sTier = SuspicionInfo.TierOf(fate.Suspicion);
        SetText(suspicionTierText, sTier.ToString());
        SetText(suspicionDetailText, $"{fate.Suspicion}/100  -  check DC {SuspicionInfo.CheckDc(fate.Suspicion)}");

        // Morale: left-edge bar (party only)
        SetActive(moralePanel, revealed && !fate.SoloMode);
        if (moraleBar != null) moraleBar.value = fate.Morale / 100f;
        string mName = MoraleName(fate.Morale);
        SetText(moraleTierText, mName);
        SetText(moraleDetailText, $"{fate.Morale}/100  -  rolls {fate.MoraleModifier:+0;-0;+0}");

        if (oddsText != null) {
            oddsText.gameObject.SetActive(!ctx.Scripted);
            float p = Odds.HitChance(ctx.Enemy.DefenseDc, ctx.RollMod, ctx.CurrentDice) * 100f;
            oddsText.text = $"Hit chance: {p:0.0}%  (need {ctx.Enemy.DefenseDc - ctx.RollMod}+ on die)";
        }

        // Profiles
        SetText(heroText, $"{ctx.Hero.DisplayName}  HP {ctx.Hero.Hp}/{ctx.Hero.MaxHp}");
        if (heroHpBar != null) heroHpBar.value = ctx.Hero.MaxHp > 0 ? (float)ctx.Hero.Hp / ctx.Hero.MaxHp : 0f;
        SetText(audacityText, $"Audacity: {fate.Audacity}");
        if (audacityPips != null) audacityPips.Set(fate.Audacity);

        SetText(enemyText, ctx.Scripted ? ctx.Enemy.DisplayName
                                        : $"{ctx.Enemy.DisplayName}  HP {ctx.Enemy.Hp}/{ctx.Enemy.MaxHp}");
        if (enemyHpBar != null) {
            enemyHpBar.gameObject.SetActive(!ctx.Scripted);
            enemyHpBar.value = ctx.Enemy.MaxHp > 0 ? (float)ctx.Enemy.Hp / ctx.Enemy.MaxHp : 0f;
        }

        if (ctx.State == BattleState.HeroTurn) {
            if (diceTray != null) diceTray.Clear();
            if (enemyDiceTray != null) enemyDiceTray.Clear();
        }
        if (heroHpTag != null) heroHpTag.Set(ctx.Hero.DisplayName, ctx.Hero.Hp, ctx.Hero.MaxHp, true);
        if (enemyHpTag != null) enemyHpTag.Set(ctx.Enemy.DisplayName, ctx.Enemy.Hp, ctx.Enemy.MaxHp, !ctx.Scripted);
        RefreshClashCards(ctx);
        RefreshSelection(ctx);
        RefreshTurnOrder(ctx);
        if (hand != null) hand.Refresh(ctx);
        if (cheatPanel != null) cheatPanel.Refresh(ctx);
    }

    // Morale tier
    static string MoraleName(int morale) =>
        morale >= 61 ? "Confident" : morale >= 50 ? "Steady" : morale >= 30 ? "Wavering" : "Breaking";

    // Clash cards
    void RefreshClashCards(BattleContext ctx) {
        if (enemyActionText != null) {
            var d = ctx.Enemy.Data;
            string name = string.IsNullOrEmpty(d.attackName) ? "Attack" : d.attackName;
            SetActive(enemyActionPanel, d.attacks);
            enemyActionText.text = ctx.Scripted
                ? name
                : $"{name}\nd{d.damageDie}{d.damageBonus:+0;-0;+0} damage\n{1 + ctx.Fate.MaliceDice} dice, keep highest"
                  + (showEnemyLandChance
                      ? $"\n{Odds.EnemyHitChance(ctx.Hero.DefenseDc, ctx.Enemy.AttackModifier, 1 + ctx.Fate.MaliceDice) * 100f:0.0}% to land if you miss"
                      : "");
        }

        bool committed = ctx.ChosenAction != PlayerAction.None;
        SetActive(heroActionPanel, committed);
        if (heroActionText != null && committed) {
            if (ctx.ChosenAction == PlayerAction.Attack)
                heroActionText.text = ctx.Scripted ? (ctx.ChosenCardTitle ?? "Attack")
                    : $"{ctx.ChosenCardTitle ?? "Attack"}\n{Odds.HitChance(ctx.Enemy.DefenseDc, ctx.RollMod, ctx.CurrentDice) * 100f:0.0}% to hit";
            else heroActionText.text = $"{ctx.ChosenCardTitle ?? "Defend"}\nHalve the hit";
        }
    }

    // Profile / passive selection
    void RefreshSelection(BattleContext ctx) {
        SetActive(heroProfilePanel, heroProfileAlwaysVisible || selected == Selected.Hero);
        if (heroSelectable != null) heroSelectable.SetSelected(selected == Selected.Hero);
        if (enemySelectable != null) enemySelectable.SetSelected(selected == Selected.Enemy);

        if (selected == Selected.Hero && heroPassives != null) {
            var lines = new List<string>(ctx.Hero.Class.passives);
            if (ctx.Progress.FateBarRevealed && ctx.Fate.MaliceDice > 0)
                lines.Insert(0, $"Jinxed: Destiny adds {ctx.Fate.MaliceDice} Malice dice (keep lowest)");
            heroPassives.Show(ctx.Hero.DisplayName, lines);
        } else if (heroPassives != null) heroPassives.Hide();

        if (selected == Selected.Enemy && enemyPassives != null)
            enemyPassives.Show(ctx.Enemy.DisplayName, ctx.Enemy.Data.passives);
        else if (enemyPassives != null) enemyPassives.Hide();
    }

    // Turn order
    void RefreshTurnOrder(BattleContext ctx) {
        if (turnOrderText == null) return;
        if (turnOrder.Count == 0) { turnOrderText.text = ""; return; }

        Unit active = null;
        switch (ctx.State) {
            case BattleState.HeroTurn: case BattleState.Roll: case BattleState.Resolve: active = ctx.Hero; break;
            case BattleState.EnemyTurn: active = ctx.Enemy; break;
        }

        var sb = new StringBuilder();
        if (ctx.Round > 0) sb.Append("Round ").Append(ctx.Round).Append("   ");
        for (int i = 0; i < turnOrder.Count; i++) {
            if (i > 0) sb.Append(turnOrderSeparator);
            var u = turnOrder[i];
            string name = u.IsDead ? $"<s>{u.DisplayName}</s>" : u.DisplayName;
            if (u == active) sb.Append("<b><color=#").Append(activeColorHex).Append('>').Append(name).Append("</color></b>");
            else sb.Append(name);
        }
        turnOrderText.text = sb.ToString();
    }

    // ---- IBattleView ----
    public void Log(string message) => SetText(logText, message);

    public void SetGm(string line) {
        SetText(gmText, line);
        SetActive(gmPanel, !string.IsNullOrEmpty(line));
        if (gmHide != null) { StopCoroutine(gmHide); gmHide = null; }
        if (gmAutoHideSeconds > 0f && !string.IsNullOrEmpty(line)) gmHide = StartCoroutine(HideGmLater());
    }

    IEnumerator HideGmLater() {
        yield return new WaitForSeconds(gmAutoHideSeconds);
        SetActive(gmPanel, false);
        gmHide = null;
    }

    public IEnumerator Tumble(int diceCount) {
        if (diceTray == null) yield break;
        yield return diceTray.Tumble(diceCount);
    }

    public void ShowRoll(RollResult roll) { if (diceTray != null) diceTray.ShowRoll(roll); }

    public IEnumerator TumbleEnemy(int diceCount) {
        if (enemyDiceTray == null) yield break;
        yield return enemyDiceTray.Tumble(diceCount);
    }
    public void ShowEnemyRoll(int[] dice, int keptIndex) { if (enemyDiceTray != null) enemyDiceTray.ShowValues(dice, keptIndex); }

    void CacheClashPositions() {
        if (heroCombatant != null) heroHome = heroCombatant.anchoredPosition;
        if (enemyCombatant != null) enemyHome = enemyCombatant.anchoredPosition;
        clashPositionsCached = heroCombatant != null && enemyCombatant != null;
    }

    public IEnumerator TumbleClash(int heroDiceCount, int enemyDiceCount) {
        Coroutine hero = diceTray != null ? StartCoroutine(diceTray.Tumble(heroDiceCount, 0.72f, 0.045f)) : null;
        Coroutine enemy = enemyDiceTray != null ? StartCoroutine(enemyDiceTray.Tumble(enemyDiceCount, 0.72f, 0.045f)) : null;
        if (hero != null) yield return hero;
        if (enemy != null) yield return enemy;
    }

    public IEnumerator ClashApproach() {
        CacheClashPositions();   // re-read: layout groups may have moved the units since Awake
        if (!clashPositionsCached) yield break;
        yield return MoveCombatants(heroHome + Vector2.right * clashMovePixels,
                                    enemyHome + Vector2.left * clashMovePixels, clashMoveDuration);
    }

    IEnumerator MoveCombatants(Vector2 heroTarget, Vector2 enemyTarget, float duration) {
        if (!clashPositionsCached) yield break;
        Vector2 h = heroCombatant.anchoredPosition;
        Vector2 e = enemyCombatant.anchoredPosition;
        float t = 0f;
        while (t < duration) {
            t += Time.deltaTime;
            float eased = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(t / duration));
            heroCombatant.anchoredPosition = Vector2.LerpUnclamped(h, heroTarget, eased);
            enemyCombatant.anchoredPosition = Vector2.LerpUnclamped(e, enemyTarget, eased);
            yield return null;
        }
        heroCombatant.anchoredPosition = heroTarget;
        enemyCombatant.anchoredPosition = enemyTarget;
    }

    public IEnumerator ClashOutcome(bool heroWon, bool enemyWon) {
        if (clashPositionsCached) {
            Vector2 heroTarget = heroHome;
            Vector2 enemyTarget = enemyHome;
            if (heroWon) { heroTarget += Vector2.right * clashWinnerPushPixels; enemyTarget += Vector2.left * clashLoserPushPixels; }
            else if (enemyWon) { enemyTarget += Vector2.left * clashWinnerPushPixels; heroTarget += Vector2.right * clashLoserPushPixels; }
            yield return MoveCombatants(heroTarget, enemyTarget, 0.16f);
            ShowFloatingClashText(heroWon ? "CLASH WON!" : enemyWon ? "CLASH LOST!" : "BOTH MISSED",
                                  heroWon ? heroCombatant : enemyWon ? enemyCombatant : null,
                                  heroWon ? new Color(0.28f, 1f, 0.48f) : enemyWon ? new Color(1f, 0.28f, 0.25f) : Color.white);
            yield return new WaitForSeconds(clashResultDuration);
            yield return MoveCombatants(heroHome, enemyHome, 0.22f);
        } else {
            ShowFloatingClashText(heroWon ? "CLASH WON!" : enemyWon ? "CLASH LOST!" : "BOTH MISSED", null, Color.white);
            yield return new WaitForSeconds(clashResultDuration);
        }
    }

    void ShowFloatingClashText(string message, RectTransform target, Color color) {
        if (rootCanvas == null) return;
        var go = new GameObject("FloatingClashResult", typeof(RectTransform), typeof(CanvasGroup), typeof(TextMeshProUGUI));
        var rect = go.GetComponent<RectTransform>();
        rect.SetParent(rootCanvas.transform, false);
        rect.sizeDelta = new Vector2(440f, 72f);
        Vector2 localPoint = Vector2.zero;
        if (target != null) {
            Vector2 screen = RectTransformUtility.WorldToScreenPoint(rootCanvas.worldCamera, target.position);
            RectTransformUtility.ScreenPointToLocalPointInRectangle(rootCanvas.transform as RectTransform,
                screen, rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : rootCanvas.worldCamera, out localPoint);
            localPoint += new Vector2(0f, 125f);
        }
        rect.anchoredPosition = localPoint;
        var text = go.GetComponent<TextMeshProUGUI>();
        text.text = message;
        text.font = TMP_Settings.defaultFontAsset;
        text.fontSize = 38f;
        text.fontStyle = FontStyles.Bold;
        text.alignment = TextAlignmentOptions.Center;
        text.color = color;
        text.outlineWidth = 0.18f;
        text.outlineColor = Color.black;
        StartCoroutine(FadeFloatingText(rect, go.GetComponent<CanvasGroup>()));
    }

    IEnumerator FadeFloatingText(RectTransform rect, CanvasGroup group) {
        float duration = clashResultDuration;
        Vector2 start = rect.anchoredPosition;
        float t = 0f;
        while (t < duration) {
            t += Time.deltaTime;
            float p = Mathf.Clamp01(t / duration);
            rect.anchoredPosition = start + Vector2.up * (34f * p);
            group.alpha = p < 0.7f ? 1f : 1f - (p - 0.7f) / 0.3f;
            yield return null;
        }
        Destroy(rect.gameObject);
    }

    public void ShowReactionPanel(bool visible) => SetActive(reactionPanel, visible);
    public void ShowContinue(bool visible) { if (continueBtn != null) continueBtn.gameObject.SetActive(visible); }
}